package com.promineotech.qAEngine.repository;

import org.springframework.data.repository.CrudRepository;

import com.promineotech.qAEngine.entity.Response;

public interface ResponseRepository extends CrudRepository<Response, Long> {

}
